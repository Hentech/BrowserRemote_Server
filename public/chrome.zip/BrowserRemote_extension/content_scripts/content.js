(function($, document) {
	chrome.runtime.sendMessage({event: "pageLoad", location:document.URL}, function(response) {});
})(jQuery, document);
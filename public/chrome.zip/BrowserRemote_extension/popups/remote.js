(function($, document, chrome) {
	$(document).ready(function() {
		chrome.runtime.sendMessage({
			event: "remote-get_session_id"
		}, function(response) {
			$('#session_id').text(response);
		});
	});
})(jQuery, document, chrome);
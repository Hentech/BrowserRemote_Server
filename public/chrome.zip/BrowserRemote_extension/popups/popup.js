(function($, document, chrome) {
	$(document).ready(function() {
		$('[state]').click(function(e) {
			chrome.runtime.sendMessage({
				event: "changeState",
				state: $(this).attr('state')
			}, function(response) {
				
			});
			chrome.browserAction.setPopup({
				popup: 'popups/' + $(this).attr('href')
			});
		});
	});
})(jQuery, document, chrome);
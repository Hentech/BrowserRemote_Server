(function($, document, chrome) {
	$(document).ready(function() {
		chrome.runtime.sendMessage({
			event:"remote-get_session_id"
		},function(response){
			if(response) $('#session_id').val(response);
		});
		$('#submit').click(function(){
			chrome.runtime.sendMessage({
				event: "display-set_session_id",
				session_id:$('#session_id').val()
			}, function(response) {
				
			});

		});
	});
})(jQuery, document, chrome);
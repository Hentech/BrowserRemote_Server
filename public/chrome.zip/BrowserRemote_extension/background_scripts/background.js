(function(chrome, io) {

	var socket = io.connect("http://henryisaweso.me"),
		onMessage = chrome.runtime.onMessage;

	window["socket"] = socket;
	socket.emit('ready');
	// A function that returns a function that calls the callback
	//  only if the event name matches
	function message_event(event_name, callback) {
		return function(request, sender, sendResponse) {
			if (request.event == event_name) callback(request, sender, sendResponse);
		};
	}
	var state = "off",
		session_id;

	// listens for when the ui has selected to be in a different state
	// those being: off, remote(transmits instructions), or display(follows intructions)
	onMessage.addListener(message_event('changeState', function(request) {
		state = request.state;
		if (state == "remote") {
			socket.emit("server-get_session_id");
			chrome.browserAction.setIcon({
				path: "imgs/icon-red.png"
			});
		} else if (state == "display") {
			session_id = undefined;
			chrome.browserAction.setIcon({
				path: "imgs/icon-blue.png"
			});
		} else {
			socket.emit("server-unbind");
			chrome.browserAction.setIcon({
				path: "imgs/icon.png"
			});
		}

	}));

	onMessage.addListener(message_event('pageLoad', function(request) {
		if (state == "remote") {
			socket.emit("pageLoad", request.location);
		}
	}));

	onMessage.addListener(message_event('remote-get_session_id', function(request, sender, sendResponse) {
		sendResponse(session_id);
	}));
	onMessage.addListener(message_event('display-set_session_id', function(request, sender, sendResponse) {
		session_id = request.session_id;
		socket.emit('server-set_session_id', session_id);
		socket.on('server-confirm_id', sendResponse);
	}));


	socket.on("locationChange", function(location) {
		if (state == "display") {
			chrome.tabs.update({
				url: location
			});
		}
	});
	socket.on("server-incoming_id", function(id) {
		session_id = id;
	});
})(chrome, io);